+ native GLES v2 render with indexed textures & uber-shader ;)
+ SDL for keyboard input & sound
+ files sorting in open file dialog
+ select last opened file

Note : use 50 Hz screen modes for full synchronization.
You can set it in /boot/config.txt
hdmi_group=1
hdmi_mode=19

Keys:
ESC - menu
Arrows, CTRL - joystick
F12 - reset
F7 - pause
F2 - quick save
F3 - quick load
F5 - start/stop tape
