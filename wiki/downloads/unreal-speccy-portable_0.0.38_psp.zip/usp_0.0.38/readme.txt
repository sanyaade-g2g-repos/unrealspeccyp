For install unpack archive contents to PSP/GAME folder.

Place data files into images folder.

Controls:

LSHIFT, SELECT	- menu.
RSHIFT, START	- virtual keys.
ARROWS + CROSS	- joystick.
SQUARE		- space.
CIRCLE		- enter.
TRIANGLE	- m.

In virtual keys you can toggle (hold) key by pressing SQUARE key.

Mega thanks to Alex for PSP 2000 for this port ;-)
